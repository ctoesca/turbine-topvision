import * as turbine from "turbine";

import Ttimer = turbine.tools.Ttimer ;
import ThttpServer = turbine.services.ThttpServer ;
import TdaoMysql = turbine.dao.TdaoMysql;
import Tapplication = turbine.Tapplication;

import Promise = require("bluebird");
import fs = require('fs');
import bodyParser = require('body-parser'); 
import express = require('express');

import {Tscheduler} from './Tscheduler';
import {Tworker} from './Tworker';
import {TpluginsManager} from './TpluginsManager';
import {TservicesDao} from './dao/TservicesDao';
import {TcommandsDao} from './dao/TcommandsDao';
import {TagentsService} from './agents/TagentsService';
import {TagentsDao} from "./dao/TagentsDao";

import {TagentsEndpoint} from "./agents/TagentsEndpoint";
import {TserviceCommand} from "./crudServices/TserviceCommand";

import PubSubServer from 'turbine-pubsub';


declare var app : Tapplication


export class Tchecker extends turbine.services.TbaseService {

	app: express.Application
	httpServer: ThttpServer
	pluginsManager
	statTimerIterval: number = 2; //sec		
	subscribeClient
	daoServices: TservicesDao
	statTimer: Ttimer
	redisClient
	scheduler: Tscheduler
	worker: Tworker
	lastStat = null;
	requestRate = 0;
	pubSubServer: PubSubServer;
	agentsService: TagentsService

	static test(){
		app.logger.error("Appel methode statique")
	}
	constructor( name, server, config)
	{
		super( name, config );
		this.httpServer = server
		this.app = express();	
		this.pubSubServer = config.pubSubServer

		var models = this.getModels();
        for (var modelName in models)
            app.registerModel(models[modelName]);

		this.app.use(bodyParser.json({
			limit: '50mb'
		}));

		this.app.post('/savePlugin', this.savePlugin.bind(this));
		this.app.get('/generateServices', this.generateServices.bind(this));
		this.app.post('/workers/:id/kill', this.killWorker.bind(this));
		this.app.post('/workers/killall', this.killAllWorker.bind(this));
		this.app.post('/workers/config', this.setWorkersConfig.bind(this));
		this.app.get('/workers/config', this.getWorkersConfig.bind(this));

		this.app.post('/scheduler/config', this.setSchedulerConfig.bind(this));
		this.app.get('/scheduler/config', this.getSchedulerConfig.bind(this));

		this.app.get('/check', this.check.bind(this));

		this.app.head('/', this.head.bind(this));
		this.app.get('/', this.test.bind(this));
		this.httpServer.use(this.config.apiPath, this.app);

		this.daoServices = app.getDao("Service");

		app.ClusterManager.on("ISMASTER_CHANGED", this.onIsMasterChanged, this);
		this.redisClient = app.ClusterManager.getClient();

		this.pluginsManager = new TpluginsManager({
			maxSamePluginInstances: this.config.worker.maxSamePluginInstances
		})
		//if (cluster.isMaster)
		this.scheduler = new Tscheduler(this.config.scheduler);
		this.scheduler.pubSubServer = this.pubSubServer

		this.worker = new Tworker(this.config.worker, this.pluginsManager);
		this.worker.pubSubServer = this.pubSubServer

		this.statTimer = new Ttimer({delay: this.statTimerIterval*1000});
		this.statTimer.on(Ttimer.ON_TIMER, this.onStatTimer, this);

		this.subscribeClient = app.ClusterManager.getNewClient();

		this.subscribeClient.on("subscribe", function (channel, count) {
			this.logger.info("subscribe success to "+channel);
		}.bind(this));

		this.subscribeClient.on("message",this.onBusMessage.bind(this));

		this.subscribeClient.subscribe("savePlugin");
		this.subscribeClient.subscribe("kill-worker");
		this.subscribeClient.subscribe("config");
		

	} 

	getModels(): any {
        return {
            "Service": {
                "name": "Service",
                IDField: "id",
                "dao": {
                    "class": TservicesDao,
                    "daoConfig": {
                        datasource: "topvision",
                        tableName: "services",
                        viewName: "view_services"
                    }
                },
                "entryPoint": {
                    path: "/services",
                    class: turbine.rest.TcrudRestEndpoint,
                    serviceClass: turbine.TcrudServiceBase
                }
            },
            "Command": {
                "name": "Command",
                IDField: "id",
                "dao": {
                    "class": TcommandsDao,
                    "daoConfig": {
                        datasource: "topvision",
                        tableName: "commands",
                        viewName: "commands"
                    }
                },
                "entryPoint": {
                    path: "/commands",
                    class: turbine.rest.TcrudRestEndpoint,
                    serviceClass: TserviceCommand
                }
            },
            "Agent": {
                "name": "Agent",
                IDField: "id",
                "dao": {
                    "class": TagentsDao,
                    "daoConfig": {
                        datasource: "topvision",
                        tableName: "agents",
                        viewName: "agents"
                    }
                },
                "entryPoint": {
                    path: "/agents",
                    class: turbine.rest.TcrudRestEndpoint,
                    serviceClass: TagentsEndpoint
                }
            }
        };
    }

	check( req, res){
		//Turbine.EventBus().send("test", "message de toto",{}, function(response){
		//	this.logger.error("REPONSE RECUE", response);
			res.status(200).send(req.user)
		//}.bind(this));
		
	}
	getDefaultConfig(){
		return {
				"active": false,
				"executionPolicy" : "one_per_process",
				"apiPath": "/api/checker",
				"scheduler":{
					"statTimerInterval": 2000,
					"scheduleInterval": 1000,
					"maxQueueLength": 1000,
					"maxScheduleSize": 5,
					"scheduleOnlyIfQueueIsEmpty": false,
					"saveInterval": 2000
				},
				"worker":{
					"maxConcurrentRequests": 5,
					"statTimerInterval": 5000,//ms
					"workInterval": 100,//ms
					"maxSamePluginInstances": 20,
					"pluginTimeout": 40//sec
				}
		}
	}


	start()
	{
		if (this.active)
		{
			
			this.worker.start();
			this.statTimer.start();

			this.lastStat = null;
			this.requestRate = 0;

			if (!this.agentsService)
			{
				this.agentsService = new TagentsService("agentsService", this.httpServer, {
					apiPath: this.config.apiPath+"/agents_service"
				})
			}

			this.agentsService.start();
			super.start()
		}
	}

	stop(){
		
		super.stop();
		this.scheduler.stop()
		this.statTimer.stop();
		if (this.agentsService)
			this.agentsService.stop();
	}

	
	onBusMessage(channel, message){
		if (!this.started)
			return;

		var messageObject = JSON.parse(message);
		this.logger.debug("message on channel " + channel );    		 
		if (channel == "savePlugin"){
			this.pluginsManager.savePlugin(messageObject);
		}else if (channel == "kill-worker")
		{
			if (messageObject.nodeId == null){
				setTimeout( function(){
					process.exit(0)
				}, 1000)
			}
			else if (messageObject.nodeId == app.ClusterManager.nodeID){

				this.logger.error("KILL NODE (id="+messageObject.nodeId+")")

				setTimeout( function(){
					process.exit(0)
				}, 1000)
			}
		}else if (channel == "config"){

			if (messageObject.action == "update_workers_config")
				this.worker.setConfig( messageObject.config )
			else if (messageObject.action == "update_scheduler_config")
				this.scheduler.setConfig( messageObject.config )
		}

	}
	  
	onIsMasterChanged(e){
		this.logger.info("ISMASTER_CHANGED (process PID="+process.pid+", worker="+process.pid+") => "+e.data);
		//if (cluster.isMaster){

			
			if (e.data){
				this.daoServices.reset().then( function(result){
					if (this.active)				
						this.scheduler.start();	
				}.bind(this),
				 function(err){		
				 	if (this.active)
				 		this.scheduler.start();								
					this.logger.error("Tplugin.onIsMasterChanged.reset ERROR "+err)
				}.bind(this));

			}else{
				this.scheduler.stop();
			}

		//}
	}

	preProcess(req, res){
		return true; 
	} 
	
	savePlugin(req,res){
		if (!this.preProcess(req, res))
			return;

		this.logger.info("savePlugin");
		
		var pluginName = req.body.name;
		var pluginSource = req.body.source;
		this.redisClient.publish("savePlugin", JSON.stringify(req.body));
		res.status(200).send(req.body);
	}

	onStatTimer(){
			
		if (this.lastStat)
		{
			var now = new Date();	
			var diff = now.getTime() - this.lastStat.getTime();

			//....
			this.lastStat = new Date();

		}else{
			this.lastStat = new Date();
		}
	}


	head(req, res){
		
		this.preProcess(req, res);			
		res.status("200").send("ok");		
	}
	
	setSchedulerConfig(req, res, next)
	{
		var config = req.body
		var message = {
			"action": "update_scheduler_config",
			"config": config
		}

		this.redisClient.publish("config", JSON.stringify(message), function(err,result){
			res.status("200").send( {result: "submitted"} );	
		});		
	}
	getSchedulerConfig(req, res, next)
	{				
		res.status(200).send( this.config.scheduler );			
	}

	setWorkersConfig(req, res, next)
	{
		var config = req.body
		var message = {
			"action": "update_workers_config",
			"config": config
		}

		this.redisClient.publish("config", JSON.stringify(message), function(err,result){
			res.status("200").send( {result: "submitted"} );	
		});		
	}

	getWorkersConfig(req, res, next)
	{				
		res.status(200).send( this.config.worker );			
	}

	killAllWorker(req, res, next)
	{
		var nodeId = req.params.id
		this.redisClient.publish("kill-worker", JSON.stringify({
			nodeId: null
		}), function(err,result){
			res.status("200").send( {result: "submitted"} );	
		});		
	}

	killWorker(req, res, next){
		var nodeId = req.params.id
		this.redisClient.publish("kill-worker", JSON.stringify({
			nodeId: nodeId
		}), function(err,result){
			res.status("200").send( {result: "submitted"} );	
		});

			
	}
	generateServices(req, res){
		
		/*
		
		nagioscfg2json.parse(req.body.nagiosConfig, function ( result ){
		   		res.status(200).send(result);		
			}.bind(this));
			
		*/
		var promises = [];
		var randId = Math.round(Math.random()*100000)
		for (var i=0; i<100; i++){
			var name = "CheckTomcatRequests_"+randId+"_"+i
			var service = {
				enabled: true,
				name: name,
				args:{
					url: "http://localhost:8090",
					port: 8090
				},
				check_interval: 2,
				id_command: 13
				
			}
			promises.push(	this.daoServices.save(service) )
		}
			
		Promise.all( promises )
		.then( function(results){
			this.logger.error("Nombre de services créés: "+results.length);
			res.send(results)
		}.bind(this),
		function(err){
			this.logger.error("error "+err.toString());
			res.status(500).send(err)
		}.bind(this))

	}

	test(req, res){
		//this.logger.info("TEST NODEID="+app.ClusterManager.nodeID);
		//this.preProcess(req, res);	
		//var user = app.connexionManager.getUserSession(req)
		//res.status("200").send( user );		
	}

}



