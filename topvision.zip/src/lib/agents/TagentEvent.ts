import * as turbine from "turbine";

import Tevent = turbine.events.Tevent

export class TagentEvent extends Tevent {

	static FAILURE = "FAILURE"

	constructor( type: string,
      eventData: any =  null,
      cancelable: boolean = true)
	{
		super(type, eventData, cancelable);
		
	} 
}


